<html>
  <head>
    <title>Include Multiple JS Files</title>
  </head>
  <body>
    <script src="wishlist-script.js"></script>
    <script src="wishlist-page.js"></script>
  </body>
</html>
