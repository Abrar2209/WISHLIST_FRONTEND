
  //  localStorage.setItem("WishlistItems",JSON.stringify([]));
  let wishlists = JSON.parse(localStorage.getItem("WishlistItems")) || [];
  function updateWishlists() {
    console.log('called update Wishlistssssss')
    const storedWishlists = JSON.parse(localStorage.getItem("WishlistItems")) || [];
    wishlists = storedWishlists;
    performFetch();

  }
  ;
  console.log('length',wishlists.length)
  let count = wishlists.length;
  let themeId;
  console.log("page title", localStorage.getItem("FormBuilderAppPageTitle"));
  console.log("Access hello", __st.cid);
  
  function performFetch() {
    console.log('Fetched');
    const requestBody = {
      wishlists,
      cid: __st.cid
    };
    fetch('http://localhost:3000/api/wishlist', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(requestBody),
    })
    .then((response) => {
      if (response.ok) {
        console.log('Wishlist items stored in the database successfully');
      } else {
        console.error('Failed to store wishlist items in the database');
      }
    })
    .catch((error) => {
      console.error('Error storing wishlist items:', error);
    });
  }
  performFetch();
  const getUserDetails = async () => {
    const accessToken = "shpua_5f5b9cada0b62ffed51ed7b081989bed"; // Replace with your access token
    const customerId = __st.cid;

    try {
    await fetch(`/admin/api/2023-04/customers/${customerId}.json`, {
        headers: {
          "X-Shopify-Access-Token": accessToken,
        },
      })
      .then(response => response.json())
      .then(data => {
        // Handle the customer details returned in the response
        console.log(data.customer);
      })
      .catch(error => {
        console.error('Error retrieving customer details:', error);
      });
  }catch(error){
    console.log(error)
  }
  }
  getUserDetails();

  async function getMainThemeId() {
    await fetch("/admin/api/2023-04/themes.json")
      .then((response) => response.json())
      .then((data) => {
        // Find the ID of the theme with role "main"
        const themes = data.themes;
        const mainTheme = themes.find((theme) => theme.role === "main");
        console.log(themes);
        console.log("Main theme ID", mainTheme.id);
        themeId = mainTheme.id;
        console.log("theme id", themeId);
        return themeId;
      })
      .catch((error) => {
        console.error("Error fetching themes:", error);
      });
  }
  // getMainThemeId();
  const createWishlistPage = async () => {
    const accessToken = "shpua_5f5b9cada0b62ffed51ed7b081989bed"; // Replace with your access token
    const pageHandle = "wishlist"; // Replace with the handle of the wishes page
  
    try {
      // Check if the page already exists
      const checkResponse = await fetch(`/admin/api/2023-04/pages.json?handle=${pageHandle}`, {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
          "X-Shopify-Access-Token": accessToken,
        },
      });
  
      if (checkResponse.ok) {
        const pageData = await checkResponse.json();
        if (pageData.pages.length > 0) {
          console.log("Wishlist page already exists:", pageData.pages[0]);
          return; // Return early if the page already exists
        }
      } else {
        console.error(
          "Failed to check wishlist page:",
          checkResponse.status,
          checkResponse.statusText
        );
        return;
      }
  
      // Create the page if it doesn't exist
      const createResponse = await fetch(`/admin/api/2023-04/pages.json`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-Shopify-Access-Token": accessToken,
        },
        body: JSON.stringify({
          page: {
            title: "Wishlist",
            handle: pageHandle,
            body_html: "<h1>Wishlist Items</h1>",
            published: true,
            template_suffix: "wisheslist-page",
          },
        }),
      });
  
      if (createResponse.ok) {
        const pageData = await createResponse.json();
        console.log("Wishlist page created:", pageData);
      } else {
        console.error(
          "Failed to create wishlist page:",
          createResponse.status,
          createResponse.statusText
        );
      }
    } catch (error) {
      console.error("Error creating wishlist page:", error);
    }
  };
  
  createWishlistPage();
  

  const getProductDetails = (productId) => {
    fetch(`/admin/api/2023-04/products/${productId}.json`)
      .then((response) => response.json())
      .then((data) => {
        // Handle the product details
        console.log("Product Detail:", data.product);
        const product = data.product;

        // Fetch the variants of the product
        fetch(`/admin/api/2023-04/products/${productId}/variants.json`)
          .then((response) => response.json())
          .then((data) => {
            // Handle the variants
            const variants = data.variants;

            // Attach the pricing information to the product object
            const productWithPrices = {
              ...product,
              variants: variants,
            };

            // Add the product to the wishlist array
            wishlists.push(productWithPrices);
            localStorage.setItem("WishlistItems",JSON.stringify(wishlists))
            // document.dispatchEvent(wishlistChangeEvent)
            // location.reload()
            alert(`Product adedddd to wishlist: ${productWithPrices.title}`);
            updateWishlists();
            updatePage();
            renderWishlist(wishlists);
          })
          .catch((error) => {
            console.error("Error fetching product variants:", error);
          });
      })
      .catch((error) => {
        console.error("Error fetching product details:", error);
      });
  };

  const removeProductFromWishlist = (productId) => {
    // console.log('wishlist in remove',wishlists)
    var r = confirm("Do you really want to remove the product");
    if(r){
      console.log('before',wishlists)
      for (var i = wishlists.length - 1; i >= 0; --i) {
        if (wishlists[i].id == productId) {
          wishlists.splice(i, 1);
        }
      }
      console.log('wishlist after remove',wishlists)
      localStorage.setItem("WishlistItems",JSON.stringify(wishlists))
      updateWishlists();
      renderWishlist(wishlists);
      updatePage();
    }
    };

  // let pageId = 120100356381;
  const addToCart =(variantId,productId)=>{
    removeProductFromWishlist(productId);
    // alert('removed product');
    const quantity = 1;
    console.log('Adding to cart: Variant ID', variantId, 'Quantity:', quantity, 'Product Id:',productId);

    const formData = {
      items: [
        {
          id: variantId,
          quantity: quantity,
        },
      ],
    };

    fetch(window.Shopify.routes.root + 'cart/add.js', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(formData),
    })
      .then((response) => {
        return response.json();
      })
      .then((data) => {
        console.log('Product added to cart:', data);
      })
      .catch((error) => {
        console.error('Error:', error);
      });
  }
  function shareProduct(productTitle) {
    if (navigator.share) {
      navigator.share({
        title: 'Check out this wishlist item!',
        text: `I wanted to share this product with you: ${productTitle} `,
        url: window.location.href
      })
        .then(() => console.log('Product shared successfully.'))
        .catch((error) => console.error('Error sharing product:', error));
    } else {
      console.log('Share API not supported.');
    }
  }

  async function createThemeTemplate() {
    const accessToken = "shpua_5f5b9cada0b62ffed51ed7b081989bed";
    // const themeId = 148606124317;
    const themeIds = await getMainThemeId();
    console.log("theme idsss in create is also", themeIds);
  // let productListHTML="<h4>HII Abrar</h4>"
    console.log("THEMEID", themeId);
    try {
      const createResponse = await fetch(
        `/admin/api/2023-01/themes/${themeId}/assets.json`,
        {
          method: "PUT",
          headers: {
            "Content-Type": "application/json",
            "X-Shopify-Access-Token": accessToken,
          },
          body: JSON.stringify({
            asset: {
              key: "templates/page.wishlist-template.liquid",
              value: `
              <div id=\"page\">\n<h1>Wishlist Items</h1>\n
              <input type="checkbox" id="select-all-checkbox" onchange="toggleAllCheckboxes()" />
              <label for="select-all-checkbox">Select All</label>
              <button onclick="moveToCart()">Move to Cart</button>
              <button onclick="removeSelectedProducts()">Remove</button>\n
              <div id='productContainer'style="display:flex"></div>\n
              </div>`,
            },
          }),
        }
      );
      // console.log(createResponse.body)
      if (createResponse.ok) {
        console.log("Template created successfully");
      } else {
        console.error(
          "Failed to create template:",
          createResponse.status,
          createResponse.statusText
        );
      }
    } catch (error) {
      console.error("Error creating template:", error);
    }
  }

  createThemeTemplate();
  window.addEventListener('focus', async function(){
    console.log('focused all')
    try {   
      const response = await fetch('http://localhost:3000/api/getWishlist');
          const data = await response.json();
          console.log('DATA', data[0].wishlist_items);
          const wishlistItems = JSON.parse(data[0].wishlist_items);
          console.log('Wishlist Items', wishlistItems);
      renderWishlist(wishlistItems);
      checkSnippetPresence(wishlistItems);
    } catch (error) {
      console.log("ERROR",error);
    }
  })
  function renderWishlist(wishlistItems) {
    try {  
      console.log('items',wishlistItems)
        let productListHTML = "";
        for (const product of wishlistItems) {
          productListHTML += `
          <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" />
          <div style="position: relative; margin: 10px;">
          ${product.variants[0].inventory_quantity != 0 ?
            `<input type="checkbox" style="position:absolute;font-size:20px" class="checkbox-item"  data-product-id="${product.id}" 
            data-variant-id="${product.variants[0].id}"/>` : `<p></p>`}
            <button data-product-id="${product.id}" style="position: absolute; top: 0; right: 0;"
            onclick="removeProductFromWishlist(${product.id})">X</button>
            <a href="/products/${product.handle}" class="product-link" target="_blank">
            <img src="${product.image.src}" style="width: 200px; height: auto;" /><br/>
            <h2>${product.title}</h2>
            <br/>
            </a>
            <h3>${product.variants[0].price}</h3>
            <br/>
            ${product.variants[0].inventory_quantity == 0 ?
              `<span style="color:red">OUT OF STOCK</span>` :
              `<button class="move-to-cart-button" data-product-title="${product.title}"
              onclick="addToCart(${product.variants[0].id}, '${product.id}')">Move to Cart</button>
              <span>IN STOCK</span>`
            }
            <button class="share-button" data-product-id="${product.id}" onclick="shareProduct('${product.title}')">
            <i class="fas fa-share"></i>
            </button>
          </div>`;
        }
  
        const wishlistContainer = document.getElementById("productContainer");
        wishlistContainer.innerHTML = productListHTML;
    } catch (error) {
      console.error('Error fetching wishlist items:', error);
    }
  }
  
  // document.addEventListener('wishlistChange', renderWishlist);

  const updatePage = async () => {
    const accessToken = "shpua_5f5b9cada0b62ffed51ed7b081989bed"; // Replace with your access token
    const pageHandle = "wishlist"; // Replace with the handle of the wishlist page

    try {
      const timestamp = Date.now();

      const response = await fetch(
      `/admin/api/2023-01/themes/148606124317/assets.json?asset[key]=templates/page.wishlist-template.liquid&_=${timestamp}`,
        {
          method: "GET",
          headers: {
            "Content-Type": "application/json",
            "X-Shopify-Access-Token": accessToken,
            "Cache-Control": "no-store, must-revalidate"
          },
        }
      );

      const pages = await response.json();
      const pageId = pages.asset.theme_id;

      let productListHTML = "";
      for (const product of wishlists) {
        productListHTML += `
          <div style="position: relative; margin: 10px;">
          <input type="checkbox" class="checkbox-item" data-product-id= "${product.id}" data-variant-id="${product.variants[0].id}"/>
            <button data-product-id="${product.id}" style="position: absolute; top: 0; right: 0;" onclick=removeProductFromWishlist(${product.id})>X</button>
            <a href="/products/{{ product.handle }}" class="product-link" target="_blank">
            <img src="${product.image.src}" style="width: 200px; height: auto;" /><br/>
            <h2>${product.title}</h2>
            </a>
            <br/>
            <h3>${product.variants[0].price}</h3>
            <br/>
            <button class="move-to-cart-button" data-product-title="${product.title}"
          onclick="addToCart(${product.variants[0].id}, '${product.id}')">Move to Cart</button>
          ${product.variants[0].inventory_quantity == 0 ?
            `<h1>OUT OF STOCK</h1>`
            : 
            `<span>IN STOCK</span>`
          }
          <button class="share-button" data-product-id="${product.id}" onclick="shareProduct('${product.title}')">
          <i class="fas fa-share"></i>
          </button>

          </div>`;
      }

      const pageData = {
        asset: {
          key: pages.asset.key,
          value: `
          <script>
          function toggleAllCheckboxes() {
            var selectAllCheckbox = document.getElementById('select-all-checkbox');
            var checkboxes = document.getElementsByClassName('checkbox-item');
          
            for (var i = 0; i < checkboxes.length; i++) {
              checkboxes[i].checked = selectAllCheckbox.checked;
            }
          }
          
          function removeSelectedProducts() {
            console.log("Clicked")
            var checkboxes = document.getElementsByClassName('checkbox-item');
            console.log(checkboxes)
            var wishlistIdsToRemove = [];
          
            
            for (var i = 0; i < checkboxes.length; i++) {
              console.log(checkboxes[i].checked)
              if (checkboxes[i].checked) {
                console.log("Product IDDD are",checkboxes[i].dataset.productId)
                wishlistIdsToRemove.push(checkboxes[i].dataset.productId);
              }
            }
            // Call a function to remove the wishlist items from the array
            console.log(wishlistIdsToRemove)
            removeWishlistItems(wishlistIdsToRemove);
          }
          function moveToCart() {
            var checkboxes = document.getElementsByClassName('checkbox-item');
            var wishlistIdsToMove = [];
        
            for (var i = 0; i < checkboxes.length; i++) {
              if (checkboxes[i].checked) {
                wishlistIdsToMove.push(checkboxes[i].dataset.productId);
              }
            }
        
            // Call a function to move the wishlist items to the cart
            moveItemsToCart(wishlistIdsToMove);
          }
          function removeWishlistItems(wishlistIds) {
            var updatedWishlists = wishlists.filter(function(item) {
              return !wishlistIds.includes(item.id.toString());
            });
          
            wishlists = updatedWishlists;
          
            console.log("Updated wishlists issseweweews:", wishlists);
            localStorage.setItem("WishlistItems",JSON.stringify(wishlists))
            updateWishlists();
            renderWishlist(wishlists);
          }    
          async function moveItemsToCart(wishlistIds) {
            try {
              for (var i = 0; i < wishlistIds.length; i++) {
                var productId = wishlistIds[i];
                console.log("P_ID", productId);
          
                var selectedProduct = wishlists.find(function (item) {
                  return item.id.toString() == productId;
                });
          
                console.log("SELECTED PRODUCT", selectedProduct);
          
                if (selectedProduct ) {
                  var variantId = selectedProduct.variants[0].id;
                  await addToCarts(variantId, productId); // Call addToCarts function
                }else if(selectedProduct.variants[0].inventory_quantity > 0){
                  alert("Can't Move-to-Cart products which are out of stock")
                }
              }
          
              console.log("All products added to cart");
              // Render the updated cart here
            } catch (error) {
              console.error("Error adding products to cart:", error);
            }
          }
          
          async function addToCarts (variantId,productId){
            //  alert('removed product');

            const quantity = 1;
            console.log('Adding to cart: Variant ID', variantId, 'Product Id:',productId);
            
            const formData = {
              items: [
                {
                  id: variantId,
                  quantity: quantity,
                },
              ],
            };
            
            await fetch(window.Shopify.routes.root + 'cart/add.js', {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
              },
              body: JSON.stringify(formData),
            })
            .then((response) => {
              return response.json();
            })
            .then((data) => {
              console.log('Product added to cart:', data);
              removeWishlistItems(productId);
            })
            .catch((error) => {
              console.error('Error:', error);
              alert(error);
              });
          }
          </script>
            <div id="page">
              <h1>Wishlist Items</h1>
              <input type="checkbox" id="select-all-checkbox" onchange="toggleAllCheckboxes()" />
              <label for="select-all-checkbox">Select All</label>
              <button onclick="moveToCart()">Move to Cart</button>
                <button onclick="removeSelectedProducts()">Remove</button>
              <div id="productContainer" style="display:flex">${productListHTML}</div>
            </div>
          `,
        },
      };

      const updateResponse = await fetch(
        `/admin/api/2023-01/themes/${pageId}/assets.json`,
        {
          method: "PUT",
          headers: {
            "Content-Type": "application/json",
            "X-Shopify-Access-Token": accessToken,
          },
          body: JSON.stringify(pageData),
        }
      );

      if (updateResponse.ok) {
        console.log("Template updated successfully");
      // location.reload(); // Reload the page to see the changes
      } else {
        console.error(
          "Failed to update page:",
          updateResponse.status,
          updateResponse.statusText
        );
      }
      
    } catch (error) {
      console.error("Error updating page:", error);
    }
    renderWishlist(wishlists);
  };
  updatePage();

  // console.log("page Id", pageId);
  const navigate = () => {
    // console.log('navigate')
    const wishlistPageUrl = "/pages/wishlist";
    window.location.href = wishlistPageUrl;
  };

  const checkSnippetPresence = (wishlists) => {
    const snippets = document.querySelectorAll(".wishlist-engine");
    // console.log(snippets);

    if (snippets.length > 0) {
      // let wishItems = localStorage.getItem("WishlistItems")
      // let wishes = JSON.parse(wishItems)
      // console.log('LISTweqqweS',wishlists)
      if(!__st.cid){
        localStorage.setItem('WishlistItems', JSON.stringify([]));
      }
      fetch('http://localhost:3000/get-excluded-product-ids')
      .then((response) => response.json())
      .then((data) => {
        const excludedProductIdsa = data.productIDs;
        const excludedProductIds = JSON.parse(excludedProductIdsa)
        console.log('excludeProducs',excludedProductIds)
      snippets.forEach((snippet) => {
        const productId = snippet.getAttribute("data-product_id"); // Retrieve the product ID
        console.log("PRODUCT ID",productId)
        if (!excludedProductIds.includes(productId)) {
        snippet.innerHTML = `
            <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css"
              integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">
            <div class="container">
              <!--<i class="fas fa-heart pulse"></i> -->
              <i class="far fa-heart js-heart heart"></i>
            </div>
          `;

        const heartDOM = snippet.querySelector(".js-heart");
        let liked = false;
        // console.log('LISTSrewewrrew',wishlists)
        wishlists.forEach(item=>{
          // console.log(item.id,parseInt(productId),item.id == parseInt(productId))
            if(item.id === parseInt(productId)){
              liked = !liked;
              // console.log('Item Id',item.id)
              heartDOM.classList.remove("far")
              heartDOM.classList.add("fas","pulse");
              // count+=1;
            }
        })
        heartDOM.onclick = (event) => {
          liked = !liked; // toggle the like (flipping the variable)

          const target = event.currentTarget;

          if (liked) {
            if (__st.cid) {
              target.classList.remove("far");
              target.classList.add("fas", "pulse");
              count += 1;
              // console.log('Product ID:', productId); // Log the product ID
              // console.log('Count:', count);
              updateWishlistCount(count);
              getProductDetails(productId); // Fetch the product details
              // createPage();
            } else {
              alert("Login to add products in wishlist");
              window.location.href = "/account/login";
            }
          } else {
            target.classList.remove("fas");
            target.classList.add("far");
            count -= 1;
            // console.log('Product ID:', productId); // Log the product ID
            // console.log('Count:', count);
            updateWishlistCount(count);
              removeProductFromWishlist(productId);
            
          }
        };

        heartDOM.addEventListener("animationend", (event) => {
          event.currentTarget.classList.remove("pulse");
        });
      }
    
      });
    }).catch((error) =>{
      console.log(error)
    })
    }
  };

  checkSnippetPresence();

  const wishlistCountDOM = document.querySelector(".wishlist-total-count");
  let wishlistCount = 0;
  wishlistCountDOM.onclick = (event) => {
    updatePage();
    navigate();
  };
  const updateWishlistCount = (count) => {
    // console.log('count in wishlist',count)
    wishlistCount = count;
    wishlistCountDOM.textContent = wishlistCount;
  };

  updateWishlistCount(count);
  